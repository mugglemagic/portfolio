import{l as o,a as r}from"../chunks/XUMD-9Mr.js";export{o as load_css,r as start};
